/*
 Fecha: 12/8/26
 Nombres y Apellidos: IHAN DAVILA Y JADET BRITAPAZ;
 Cedula: 30649058 y 32980885
 Seccion: [Seccion: 3]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <math.h>
#include <assert.h>

#define MAX_INVENTARIO 50
#define MAX_BESTIARIO 100
#define MAX_OBJETOS 100

//estructuras

typedef struct {
	int id;
	char nombre[50];
	int valor;
	char tipo_efecto[30];
} objeto;

typedef struct {
	int id;
	char nombre[50];
	int hp_base;
	int hp_actual;
	int atk_base;
	int def_base;
	char tipo[10];//comun o raro
} entidad;

typedef struct { 
	//stats del jugador y variables de config.txt, para no hacer otro struct
	int hp_max;
	int hp_actual;
	int atk_base;
	int def_base;
	int nivel;
	int xp_actual;
	int xp_siguiente_nivel;

	//progreso
	int piso_actual;
	int cuarto_actual;
	int total_pisos;
	int cuartos_base_por_piso;

	//inventario
	objeto inventario[MAX_INVENTARIO];
	int tamano_inventario;
	int objetos_en_inventario;

	//metricas
	int enemigos_derrotados;
	int objetos_consumidos;
	int semilla;
	
	//llamadas al rand (para sincronizar la con la partida guardada)
	int rng_pasos;
} estado_juego;

typedef struct {
	char nombre[30];
	int nivel;
	int piso_alcanzado;
	int enemigos_derrotados;
	char estado_final[20]; 
	int hp_final;        
	int atk_final;        
	int def_final;        
	int objetos_usados;    
} score;

//limpiador de buffer

void limpiar_buffer() {
	int c;
	while ((c = getchar()) != '\n' && c != EOF);
}

void registrar_highscores(estado_juego juego,int es_victoria) {
	char nombre_jugador[30];
	
	if (es_victoria) {
		printf("\n--- VICTORIA! HAS LLEGADO AL NUCLEO ---\n");
	} else {
		printf("\n--- FIN DE LA AVENTURA ---\n");
	}
	
	printf("Introduce tu nombre para el Salon de la Fama (sin espacios): ");
	if (scanf("%29s", nombre_jugador) != 1) {
		sprintf(nombre_jugador, "HeroeAnonimo");
	}
	limpiar_buffer();
	
	int hp_registrado = juego.hp_actual;
	if (hp_registrado < 0) hp_registrado = 0;
	 
	FILE *archivo = fopen("highscores.txt", "a");
	if (archivo == NULL) {
		printf("\n[!] Error al abrir el Salon de la Fama.\n");
		return;
	}

	fprintf(archivo, "%s %d %d %d %s %d %d %d %d\n",
		nombre_jugador,
		juego.nivel,
		juego.piso_actual,
		juego.enemigos_derrotados,
		es_victoria ? "Victoria" : "Derrota",
		hp_registrado,
		juego.atk_base,
		juego.def_base,
		juego.objetos_consumidos
	);

	fclose(archivo);
	printf("\n[*] tu partida ha sido registrada en el Salon de la Fama!\n");
}

void mostrar_highscores() {
    FILE *archivo = fopen("highscores.txt", "r");
    if (archivo == NULL) {
        printf("\n[!] Todavia no hay registros en el Salon de la Fama.\n");
        return;
    }

    char nombre[30], estado[20];
    int nivel, piso, enemigos, hp, atk, def, objetos;
    int registros_encontrados = 0;

    printf("\n=================================== SALON DE LA FAMA ===================================\n");
    printf("%-15s | %-10s | %-6s | %-6s | %-10s | %-8s | %-5s | %-5s | %-7s\n", 
           "Nombre", "Estado", "Nivel", "Piso", "Enemigos", "HP Fin", "ATK", "DEF", "Usados");
    printf("----------------------------------------------------------------------------------------\n");

    // Lee línea por línea asegurándose de que capture exactamente los 9 valores
    while (fscanf(archivo, "%29s %d %d %d %19s %d %d %d %d", 
                  nombre, &nivel, &piso, &enemigos, estado, &hp, &atk, &def, &objetos) == 9) {
        
        printf("%-15s | %-10s | Lv.%-3d | P.%-3d | %-10d | %-8d | %-5d | %-5d | %-7d\n", 
               nombre, estado, nivel, piso, enemigos, hp, atk, def, objetos);
        
        registros_encontrados++;
    }

    if (registros_encontrados == 0) {
        printf("                (El archivo esta vacio o tiene un formato incompatible)\n");
    }

    printf("========================================================================================\n");
    fclose(archivo);
}

//prototipos de modulo 1 

estado_juego cargar_configuracion();
int cargar_bestiario(entidad bestiario[]);
int cargar_objetos(objeto catalogo[]);

void mostrar_estado_jugador(estado_juego juego);
estado_juego iniciar_partida(estado_juego juego, entidad bestiario[], int total_enemigos, objeto catalogo[], int total_objetos);

//prototipos de modulo 2

int generar_evento_cuarto();
entidad seleccionar_enemigo_semilla(entidad bestiario[], int total_enemigos);
objeto seleccionar_objeto_semilla(objeto catalogo[], int total_objetos);

estado_juego agregar_objeto_inventario(estado_juego juego, objeto nuevo_item) {
	
	if (juego.objetos_en_inventario < juego.tamano_inventario) {
		juego.inventario[juego.objetos_en_inventario] = nuevo_item;
		juego.objetos_en_inventario++;
		printf(" [+] objeto guardado en el inventario (%d/%d)!\n", juego.objetos_en_inventario, juego.tamano_inventario);
	} else {
		printf(" [!] inventario lleno! No puedes cargar con %s.\n", nuevo_item.nombre);
	}
	
    return juego;
}

void guardar_partida(estado_juego juego) {
    FILE *archivo = fopen("partida.txt", "w");
    if (archivo == NULL) {
		printf("\n[!] error: No se pudo crear el archivo de guardado.\n");
		return;
	}

	fprintf(archivo, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
		juego.piso_actual,
		juego.cuarto_actual,
		juego.nivel,
		juego.hp_actual,
		juego.hp_max,
		juego.atk_base,
		juego.def_base,
		juego.xp_actual,
		juego.xp_siguiente_nivel,
		juego.enemigos_derrotados,
		juego.objetos_consumidos,
		juego.tamano_inventario,
		juego.objetos_en_inventario,
		juego.rng_pasos,
		juego.semilla
	);
	
	int i;
	for (i = 0; i < juego.objetos_en_inventario; i++) {
		fprintf(archivo, "%d %s %d %s\n",
			juego.inventario[i].id,
			juego.inventario[i].nombre,
			juego.inventario[i].valor,
			juego.inventario[i].tipo_efecto
		);
	}

	fclose(archivo);
	printf("\n[*] Partida guardada con exito en 'partida.txt'!\n");
}

estado_juego cargar_partida(estado_juego juego_base) {
	FILE *archivo = fopen("partida.txt", "r");

	if (archivo == NULL) {
		printf("\n[!] No se encontro ninguna partida guardada previa.\n");
		juego_base.nivel = 0; 
		return juego_base;
	}

	if (fscanf(archivo, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
			&juego_base.piso_actual,
			&juego_base.cuarto_actual, 
			&juego_base.nivel,
			&juego_base.hp_actual,
			&juego_base.hp_max,
			&juego_base.atk_base,
			&juego_base.def_base,
			&juego_base.xp_actual,
			&juego_base.xp_siguiente_nivel,
			&juego_base.enemigos_derrotados,
			&juego_base.objetos_consumidos,
			&juego_base.tamano_inventario,
			&juego_base.objetos_en_inventario,
			&juego_base.rng_pasos,
			&juego_base.semilla) != 15)
	{
		printf("\n[!] Error: El archivo de guardado esta corrupto o incompleto.\n");
		fclose(archivo);
		juego_base.nivel = 0;
		return juego_base;
	}

	int i;
	for (i = 0; i < juego_base.objetos_en_inventario; i++) {
		fscanf(archivo, "%d %49s %d %29s",
			&juego_base.inventario[i].id,
			juego_base.inventario[i].nombre,
			&juego_base.inventario[i].valor,
			juego_base.inventario[i].tipo_efecto
		);
	}

	fclose(archivo);
	printf("\n[*] Partida cargada con exito! Bienvenido de nuevo.\n");
	return juego_base;
}

estado_juego usar_inventario(estado_juego juego) {

    if (juego.objetos_en_inventario == 0) {
        printf("\n> No tienes ningun objeto en el inventario!\n");
        printf(" Presiona Enter para continuar...");
        char temp[100];
        fgets(temp, sizeof(temp), stdin);
        return juego;
    }

    printf("\n--- INVENTARIO DE OBJETOS ---\n");
    int i;
    for (i = 0; i < juego.objetos_en_inventario; i++) {
        printf("%d. %s (efecto: %s, valor: %d)\n", 
            i + 1, 
            juego.inventario[i].nombre, 
            juego.inventario[i].tipo_efecto, 
            juego.inventario[i].valor);
    }
    
    printf("0. cancelar (volver)\n");
    printf("Elige el objeto a manipular: ");

    int eleccion_obj = 0;
    
    if (scanf("%d", &eleccion_obj) != 1) {
        eleccion_obj = 0;
    }
    limpiar_buffer();

    if (eleccion_obj <= 0 || eleccion_obj > juego.objetos_en_inventario) {
        printf("\n> Has cancelado el uso del inventario.\n");
        return juego; 
    }

    int indice = eleccion_obj - 1;
    objeto item_usado = juego.inventario[indice];
    
    printf("\nQue quieres hacer con tu item (%s) ?\n", item_usado.nombre);
    printf(" 1. Usar\n");
    printf(" 2. Soltar \n");
    printf(" Elige una opcion [1-2]: ");
    
    int accion_item = 0;
    if (scanf("%d", &accion_item) != 1) {
        accion_item = 0;
    }
    limpiar_buffer();

    if (accion_item == 1) {
        if (strcmp(item_usado.tipo_efecto, "CURA") == 0) {
            juego.hp_actual += item_usado.valor;
            if (juego.hp_actual > juego.hp_max) {
                juego.hp_actual = juego.hp_max; 
            }
            printf("\n> Usas %s! Recuperas %d puntos de HP.\n", item_usado.nombre, item_usado.valor);
        }
        else if (strcmp(item_usado.tipo_efecto, "ATK_PERM") == 0) {
            juego.atk_base += item_usado.valor;
            printf("\n> Usas %s! Tu ataque base aumenta permanentemente en %d.\n", item_usado.nombre, item_usado.valor);
        }
        else if (strcmp(item_usado.tipo_efecto, "DEF_PERM") == 0) {
            juego.def_base += item_usado.valor;
            printf("\n> Usas %s! Tu defensa base aumenta permanentemente en %d.\n", item_usado.nombre, item_usado.valor);
        }
        
        juego.objetos_consumidos++;
	} 
	
	else if (accion_item == 2) {
        printf("\n> Has tirado el objeto al piso: %s.\n", item_usado.nombre);
    } 
	
	else {
        printf("\n> Opcion no valida. No haces nada con el objeto.\n");
        return juego;
    }


    int j;
    for (j = indice; j < juego.objetos_en_inventario - 1; j++) {
        juego.inventario[j] = juego.inventario[j + 1];
    }
    
    juego.objetos_en_inventario--;

    return juego;
}
	
estado_juego iniciar_combate(estado_juego jugador, entidad enemigo_actual, int es_jefe_obligatorio, objeto catalogo[], int total_objetos) {
	printf("\nun %s salvaje se interpone en tu camino!\n", enemigo_actual.nombre);

	while (jugador.hp_actual > 0 && enemigo_actual.hp_actual > 0) {

		printf("\n.___________________________________________________.\n");
		printf("|                                                   |\n");
		printf("|  .:: FASE DE COMBATE ::.                          |\n");
		printf("|___________________________________________________|\n");
		printf("\n   TU HP: %d / %d  |  %s HP: %d / %d\n\n",
		jugador.hp_actual, jugador.hp_max,enemigo_actual.nombre, 
		enemigo_actual.hp_actual, enemigo_actual.hp_base);
		printf(".---------------------------------------------------.\n");
		printf("|  (1) Atacar                                       |\n");
		printf("|  (2) Usar Objeto                                  |\n");
		printf("|  (3) Ver Estado (Stats)                           |\n");
					
		if (!es_jefe_obligatorio) {
			printf("|  (4) Huir                                         |\n");
		} else {
			printf("|  (4) Huir (BLOQUEADO - Es el Jefe del Piso!)      |\n");
		}
		
		printf(".---------------------------------------------------.\n");
		printf("  Elige tu accion [1-4]: ");
		
		int accion;
		if (scanf("%d", &accion) != 1) {
			accion = 0;
		}
		limpiar_buffer();

		//turno del Jugador
		if (accion == 1) {
			int dano_causado = jugador.atk_base - enemigo_actual.def_base;
			if (dano_causado < 1) dano_causado = 1;
			 
			enemigo_actual.hp_actual -= dano_causado;
			printf("\n> atacas al %s y le causas %d puntos de dano.\n", enemigo_actual.nombre, dano_causado);
		} 
		
		else if (accion == 2) {
			jugador = usar_inventario(jugador);
		}
		
		else if (accion == 3) {
			mostrar_estado_jugador(jugador);
			continue; // Ver stats no gasta turno
		} 	
		
		else if (accion == 4) {

			if (es_jefe_obligatorio) {
				printf("\n> el jefe bloquea cualquier espacio, estás obligado a pelear.\n");
				continue; 
			}			

			int probabilidad_huida = 35 + (jugador.def_base * 2) - (enemigo_actual.atk_base);
			
			if (probabilidad_huida < 10) probabilidad_huida = 10;
			if (probabilidad_huida > 85) probabilidad_huida = 85;

			int tirada_exito = rand() % 100; 
			jugador.rng_pasos++;
			
			if (tirada_exito < probabilidad_huida) {
				printf("\n> te escapas de chiripa, vives un dia mas.\n", probabilidad_huida);
				return jugador; 
			} else {
				printf("\n> Intentas huir, pero el %s te corta el paso y te obliga a seguir peleando.\n", enemigo_actual.nombre);
			}
		}

        else {
            printf("\n> accion no valida. pierdes la concentracion...\n");
        }
        
		// ver si el enemigo murio
		if (enemigo_actual.hp_actual <= 0) {
			printf("\nhas derrotado al %s!\n", enemigo_actual.nombre);
	            
			int xp_ganada = 30;
			if (strcmp(enemigo_actual.tipo, "Comun") == 0) xp_ganada = 20;
			else if (strcmp(enemigo_actual.tipo, "Raro") == 0) xp_ganada = 50;
			
			jugador.xp_actual += xp_ganada;
			jugador.enemigos_derrotados++;
			printf("ganas %d puntos de experiencia.\n", xp_ganada);
				
			//es while por si sube de nivel 2 veces			
			while (jugador.xp_actual >= jugador.xp_siguiente_nivel) { 
				jugador.nivel++;
				jugador.xp_actual -= jugador.xp_siguiente_nivel;	
				jugador.xp_siguiente_nivel = (int)(jugador.xp_siguiente_nivel * 1.5);
	    
				// incrementos de stats al subir de nivel
				jugador.hp_max += 15;
				jugador.hp_actual = jugador.hp_max; // Cura al subir de nivel
				jugador.atk_base += 3;
				jugador.def_base += 2;
	    
				printf("\nHAS SUBIDO AL NIVEL %d! tus stats han aumentado.\n", jugador.nivel);
			}
			
			if (total_objetos > 0) {
				int suelta_objeto = 0;

				if (strcmp(enemigo_actual.tipo, "Raro") == 0) {
					suelta_objeto = 1;

				} else {
					suelta_objeto = (rand() % 2 == 0); 
					jugador.rng_pasos++;
				}

				if (suelta_objeto) {
					int indice_objeto = rand() % total_objetos;
					jugador.rng_pasos++;
					objeto item_dropeado = catalogo[indice_objeto];

					// validacion
					if (jugador.objetos_en_inventario < jugador.tamano_inventario) {
						jugador.inventario[jugador.objetos_en_inventario] = item_dropeado;
						jugador.objetos_en_inventario++;
						printf("\n> El enemigo ha soltado un objeto: %s!\n", item_dropeado.nombre);
						printf("> Lo has guardado en tu inventario.\n");
					} else {
						printf("\n> El enemigo solto %s, pero tu inventario esta lleno y no puedes cargarlo!\n", item_dropeado.nombre);
					}
				}
			}
				
			return jugador; 
		}
	
		// turno del enemigo
		int dano_recibido = enemigo_actual.atk_base - jugador.def_base;
		if (dano_recibido < 1) dano_recibido = 1;
			
		jugador.hp_actual -= dano_recibido;
		printf("> El %s contraataca y te causa %d puntos de dano.\n", enemigo_actual.nombre, dano_recibido);
	
		// chequear si el jugador murio
		if (jugador.hp_actual <= 0) {
			printf("\ncaes inconsciente... tu aventura termina aqui.\n");
			printf("      $$$$$$$$$$$\n");
		    printf("    $$$$$$$$$$$$$$$\n");
		    printf("  $$$     $$$     $$$\n");
		    printf(" $$$      $$$      $$$\n");
		    printf(" $$      $   $      $$\n");
		    printf(" $$$$$$$$     $$$$$$$$\n");
		    printf(" $$$$$$$$$$$$$$$$$$$$$\n");
		    printf(" $$    $$ $ $ $$    $$\n");
		    printf("   $   $       $   $\n");
		    printf("   $               $\n");
		    printf("   $               $\n");
		    printf("   $$             $$\n");
		    printf("   $$$  $ $ $ $  $$$\n");
		    printf("    $$$$$$$$$$$$$$$\n");
		    printf("      $$$$$$$$$$$\n");
			registrar_highscores(jugador, 0);
			return jugador;
		}
	}
	
	return jugador;
}

void mostrar_estado_jugador(estado_juego juego) {
	printf("\n.___________________________________________________.\n");
	printf("|                                                   |\n");	
	printf("|  .:: ESTADO DEL EXPLORADOR ::.                    |\n");
	printf("|___________________________________________________|\n");
	printf("|                                                   |\n");
	printf("|  [+] NIVEL:       %-3d                             |\n", juego.nivel);
	printf("|  [+] EXPERIENCIA: %d / %-5d                       |\n", juego.xp_actual, juego.xp_siguiente_nivel);
	printf("|  [+] VITALIDAD:   %d / %-5d                     |\n", juego.hp_actual, juego.hp_max);
	printf("|  [+] ATAQUE:      %-3d                             |\n", juego.atk_base);
	printf("|  [+] DEFENSA:     %-3d                             |\n", juego.def_base);
	printf("|---------------------------------------------------|\n");
	printf("|  [>] UBICACION:   Piso %d / %d  |  Cuarto %-2d        |\n", juego.piso_actual, juego.total_pisos, juego.cuarto_actual);
	printf("|  [>] INVENTARIO:  %d / %-2d objetos                  |\n", juego.objetos_en_inventario, juego.tamano_inventario);
	printf("|___________________________________________________|\n\n");
}

int main() {
	estado_juego juego;
	entidad bestiario[MAX_BESTIARIO];
	objeto catalogo_objetos[MAX_OBJETOS];
	
	printf("----------EL DESCENSO AL NUCLEO-------------\n");
    printf("cargando archivos de configuracion...\n\n");

    juego = cargar_configuracion();

    int total_enemigos = cargar_bestiario(bestiario);       
    int total_objetos = cargar_objetos(catalogo_objetos);  

    if (total_enemigos == 0 || total_objetos == 0) {    
        printf("error: bestiario.txt u objetos.txt no tienen registros validos\n");    
        return 1; 
    }

	int opcion = 0;
	
	/*
	-------------------------------------------------------------------------------------------
    prueba de funcionamiento de contadores(funcionan):
    
    printf("Configuracion cargada (Semilla: %d, Vida Max: %d)\n", juego.semilla, juego.hp_max);
    printf("Bestiario cargado: %d enemigos leidos.\n", total_enemigos);
    printf("Objetos cargados: %d objetos leidos.\n\n", total_objetos);
    -------------------------------------------------------------------------------------------
	*/
	
	do {
		
		printf(".___________________________________________________.\n");
		printf("|                                                   |\n");		
        printf("|  .:: EL DESCENSO AL NUCLEO ::.                    |\n");
		printf("|___________________________________________________|\n");
		printf("|                                                   |\n");
		printf("|  (1) NUEVA PARTIDA                                |\n");
		printf("|  (2) CARGAR PARTIDA                               |\n");
		printf("|  (3) SALON DE LA FAMA(highscore)                  |\n");
		printf("|  (4) SALIR                                        |\n");
		printf("|___________________________________________________|\n");
		printf("  ingresa comando [1-4]: ");
		
		char entrada[100];
        opcion = 0;
        
		if (fgets(entrada, sizeof(entrada), stdin) != NULL) {
            if (sscanf(entrada, "%d", &opcion) != 1) {
                opcion = 0; 
            }
        }
        
		switch (opcion) {
			case 1:
				
				printf("\niniciando nueva partida.....................");
				juego = cargar_configuracion();
				juego = iniciar_partida(juego, bestiario, total_enemigos, catalogo_objetos, total_objetos);
				
				break;

			case 2: {
			    estado_juego juego_cargado = cargar_partida(juego);        
			
			    if (juego_cargado.nivel > 0) {
			        juego = juego_cargado;
			        
			        srand(juego.semilla);    
			        int i;
			        for (i = 0; i < juego.rng_pasos; i++) {
			            rand();
			        }				
			        
					//verificado el contador
			        //printf("[!] Sincronizacion RNG completada (%d pasos).\n", juego.rng_pasos);
			        
			        
			        int decision_post_carga = 0;
			        do {
			            printf("\n.___________________________________________________.\n");
			            printf("|  .:: MENU DE PARTIDA CARGADA ::.                  |\n");
			            printf("| 1. Continuar explorando (Entrar a la mazmorra)    |\n");
			            printf("| 2. Ver stats del personaje                        |\n");
			            printf("| 3. Usar inventario (Items / Mochila)              |\n");
			            printf("| 4. Volver al menu principal                       |\n");
			            printf("|___________________________________________________|\n");
			            printf(" Elige una opcion: ");
			            
			            char entrada_carga[100];
			            if (fgets(entrada_carga, sizeof(entrada_carga), stdin) != NULL) {
			                sscanf(entrada_carga, "%d", &decision_post_carga);
			            }
			
			            if (decision_post_carga == 1) { 
			                juego = iniciar_partida(juego, bestiario, total_enemigos, catalogo_objetos, total_objetos);
			                break;
			            } 
			            else if (decision_post_carga == 2) {
			                mostrar_estado_jugador(juego);
			            } 
			            else if (decision_post_carga == 3) {
			                juego = usar_inventario(juego);
			            } 
			            else if (decision_post_carga == 4) {
			                printf("\nVolviendo al menu principal...\n");
			                break;
			            } 
			            else {
			                printf("\n> Opcion invalida.\n");
			            }
			        } while (decision_post_carga != 4);
				} 
				
				else {
			        printf("\n[!] No se pudo cargar la partida.\n");
			    }
			    break;
			}

			case 3:
				mostrar_highscores();
				break;

			case 4:
				printf("\n gracias por jugar,saliendo....\n");
				break;

				default:
				printf("\n opcion invalida. por favor, ingresa un numero entre 1 y 4.\n\n");
				break;
		}

	} while (opcion != 4);

	return 0;
}

//inicializacion de modulos

estado_juego cargar_configuracion() {
	FILE *apun = fopen("config.txt", "r");
	estado_juego actual;

	if (apun == NULL) {
		printf("error al abrir config.txt\n");
		exit(1);
	}

	//lectura del archivo config.txt
	fscanf(apun, "%d", &actual.semilla);
	fscanf(apun, "%d", &actual.total_pisos);
	fscanf(apun, "%d", &actual.cuartos_base_por_piso);
	fscanf(apun, "%d %d %d %d", 
			&actual.hp_max, 
			&actual.atk_base, 
			&actual.def_base, 
			&actual.tamano_inventario);
			
	//validacion
	if (actual.tamano_inventario < 1 || actual.tamano_inventario > MAX_INVENTARIO) {
		printf("config.txt: el inventario debe estar entre 1 y %d\n", MAX_INVENTARIO);
		fclose(apun); 
		exit(1);
	}

	fclose(apun);

	//inicializacion de las variables de estado del jugador
	actual.hp_actual = actual.hp_max;
	actual.nivel = 1;
	actual.xp_actual = 0;
	actual.xp_siguiente_nivel = 100;
	actual.piso_actual = 1;
	actual.cuarto_actual = 0;
	actual.objetos_en_inventario = 0;
	actual.enemigos_derrotados = 0;
	actual.objetos_consumidos = 0;
	
	//inicializacion de contador de llamadas de rand (para sincronizar la bendita seed)
	actual.rng_pasos = 0;

	srand(actual.semilla);

	return actual;
}

int cargar_bestiario(entidad bestiario[]) {
	FILE *apun = fopen("bestiario.txt", "r");
	if (apun == NULL) {
		printf("error al abrir bestiario.txt\n");
		exit(1);
    }

	int total = 0;
	while (total < MAX_BESTIARIO && 
		fscanf(apun, "%d %49s %d %d %d %9s", 
				&bestiario[total].id,
				bestiario[total].nombre,
				&bestiario[total].hp_base,
				&bestiario[total].atk_base,
				&bestiario[total].def_base,
				bestiario[total].tipo) == 6) 		
	{
		bestiario[total].hp_actual = bestiario[total].hp_base;
		total++;
	}
	
	fclose(apun);
	return total;
}

int cargar_objetos(objeto catalogo[]) {
	FILE *apun = fopen("objetos.txt", "r");

	if (apun == NULL) {
		printf("error al abrir objetos.txt\n");
		exit(1);
    }   

	int total = 0;

	while (total < MAX_OBJETOS && 
		fscanf(apun, "%d %49s %d %29s", 
				&catalogo[total].id,
				catalogo[total].nombre,
				&catalogo[total].valor,
				catalogo[total].tipo_efecto) == 4)
	{
		total++;
    }

	fclose(apun);
	return total;
}

entidad seleccionar_enemigo_semilla(entidad bestiario[], int total_enemigos) {
	int indice = rand() % total_enemigos;
	return bestiario[indice];
}

objeto seleccionar_objeto_semilla(objeto catalogo[], int total_objetos) {
	int indice = rand() % total_objetos;
	return catalogo[indice];
}

estado_juego iniciar_partida(estado_juego juego, entidad bestiario[], int total_enemigos, objeto catalogo[], int total_objetos) {
	printf("\n.___________________________________________________.\n");
	printf("|                                                   |\n");	
	printf("|  .:: DESCENDIENDO HACIA EL NUCLEO ::.             |\n");
	printf("|___________________________________________________|\n");
	printf(" \nTe adentras en la oscuridad de la estructura...\n");
    
    
	//muestra la ficha inicial del personaje
	mostrar_estado_jugador(juego);
    
	printf(" [>] presiona ENTER para ingresar al cuarto...");
	getchar();
	    
    //bucle principal de exploracion
	while (juego.hp_actual > 0 && juego.piso_actual <= juego.total_pisos) {
		juego.cuarto_actual++;

		printf("\n.___________________________________________________.\n");
		printf("|						    |\n");		
		printf("|	PISO %d / %-2d 	|	CUARTO %-2d	    |\n",juego.piso_actual, juego.total_pisos, juego.cuarto_actual);
		printf("|___________________________________________________|\n");
		
		int cuartos_este_piso = juego.cuartos_base_por_piso;
		
		if(juego.cuarto_actual > cuartos_este_piso){
			printf("\n.___________________________________________________.\n");
			printf("|                                                   |\n");
			printf("|   [! ALERTA !] Esta es la ultima sala del piso!   |\n");
		    printf("|                                                   |\n");			
			printf("|      Un poderoso jefe bloquea tu salida!          |\n");
			printf("|___________________________________________________|\n");

			entidad jefe;
			int jefe_encontrado = 0;
			
			entidad posibles_jefes[MAX_BESTIARIO];
			int total_jefes = 0;
			int i;
			for (i = 0; i < total_enemigos; i++) {
				if (strcmp(bestiario[i].tipo, "raro") == 0 || strcmp(bestiario[i].tipo, "Raro") == 0) {
					posibles_jefes[total_jefes] = bestiario[i];
					total_jefes++;
				}
			}
			
			if (total_jefes > 0) {
				int indice_aleatorio = rand() % total_jefes;
				juego.rng_pasos++;
				jefe = posibles_jefes[indice_aleatorio];
				jefe_encontrado = 1;
			}
			
			else if (total_enemigos > 0) {
				jefe = bestiario[total_enemigos - 1];
				jefe_encontrado = 1;
			}

			jefe.hp_actual = jefe.hp_base;
			juego = iniciar_combate(juego, jefe, 1, catalogo, total_objetos);
			
			if (juego.hp_actual <= 0) {
				break;
			}
			
			printf("\n [^] Has derrotado al jefe del Piso %d! Descendiendo al siguiente nivel...\n", juego.piso_actual);
			juego.piso_actual++;   // sube al siguiente piso
			juego.cuarto_actual = 0; // reinicia el contador de cuartos para el nuevo piso
		}
		
		else{
			
			entidad enemigo = seleccionar_enemigo_semilla(bestiario, total_enemigos);
			juego.rng_pasos++;
					
			printf("\n [!] un enemigo acecha en las sombras!: %s\n", enemigo.nombre);
			printf("     STATS -> HP: %d | ATK: %d | DEF: %d | TIPO: %s\n",enemigo.hp_base, enemigo.atk_base, enemigo.def_base, enemigo.tipo);
					                
			juego = iniciar_combate(juego, enemigo, 0, catalogo, total_objetos);
			
		}

		if (juego.hp_actual > 0 && juego.piso_actual <= juego.total_pisos) {
		    int decision_tomada = 0; // bandera 
		
		    while (!decision_tomada) {
		        char entrada[100];
		        int opc_cuarto = 0;
		
				printf("\n.___________________________________________________.\n");
				printf("|                                                   |\n");                
				printf("| Que deseas hacer ahora?                           |\n");
				printf("| 1. Avanzar al siguiente cuarto                    |\n");
				printf("| 2. Ver stats                                      |\n");		        
				printf("| 3. Usar inventario                                |\n");
				printf("| 4. Guardar partida y continuar explorando         |\n");
				printf("| 5. Guardar partida y salir al menu principal      |\n");            
				printf("|___________________________________________________|\n");
				printf("  Elige una opcion: ");

				if (fgets(entrada, sizeof(entrada), stdin) != NULL) {
					sscanf(entrada, "%d", &opc_cuarto);
				}
		
				if (opc_cuarto == 1) {
					decision_tomada = 1; 
				}
				else if (opc_cuarto == 2) {
					mostrar_estado_jugador(juego);
				} 
		        
				else if (opc_cuarto == 3) {
					juego = usar_inventario(juego);
				} 
				else if (opc_cuarto == 4) {
					guardar_partida(juego);
					printf("\n [!] Partida guardada con exito! Puedes seguir explorando.\n");
				}
				else if (opc_cuarto == 5) {
					guardar_partida(juego);
					printf("\n [!] Saliendo al menu principal...\n");
					return juego;
				}
				else {
					printf("\n> Opcion invalida. Elige un numero del 1 al 5.\n");
				}
			}
		}
	}

	if (juego.piso_actual > juego.total_pisos) {
		printf("\n.___________________________________________________.\n");
		printf("|                                                   |\n");		
		printf("| .:: HAS ALCANZADO EL NUCLEO Y GANADO EL JUEGO! ::.|\n");
		printf("|___________________________________________________|\n\n");
		registrar_highscores(juego, 1);		
	}
	return juego;
}
